import React from 'react';
import SmartForm from './components/SmartForm';
import './styles/SmartForm.css';

const App = () => {
  return (
    <div className="App">
      <h1>Smart Form</h1>
      <SmartForm />
    </div>
  );
};

export default App;